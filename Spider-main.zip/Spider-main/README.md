# Spider
Code to execute spider

To execute, go to bash language and insert following:
node spider.js -r -l 3 -p ./path ~Your URL~ 

Note: Remove ~ symbols
